﻿using System;
using System.Threading;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;
using System.IO;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;

namespace Polymetal.Exchange.Revit
{
    internal class RevitExchangeAddin : IExternalApplication
    {
        private Mutex mutex = new Mutex(true, "ExchangeMutex");
        private string _filePath;
        private string _exchangeType;
        private string _ifcPath;

        public Result OnStartup(UIControlledApplication a)
        {
            var taskInfo = Environment.GetEnvironmentVariable("PLMT_EXCHANGE").Split('#');

            _filePath = taskInfo.Length >= 1 ? taskInfo[0] : string.Empty;
            _exchangeType = taskInfo.Length >= 2 ? taskInfo[1] : string.Empty;
            _ifcPath = taskInfo.Length >= 3 ? taskInfo[2] : string.Empty;

            mutex.WaitOne();
            if (!string.IsNullOrEmpty(_filePath))
            {
                var fInfo = new FileInfo(_filePath);
                File.Create(Path.Combine(fInfo.DirectoryName, "mutex.init"));
            }
            a.ControlledApplication.ApplicationInitialized += OnApplicationInitialized;
            return Result.Succeeded;
        }

        protected void OnApplicationInitialized(object sender, ApplicationInitializedEventArgs e)
        {
            if (string.IsNullOrEmpty(_filePath) || string.IsNullOrEmpty(_exchangeType) || string.IsNullOrEmpty(_ifcPath))
                return;

            var app = sender as Application;
            var uiApp = new UIApplication(app);
            var uiDoc = uiApp.OpenAndActivateDocument(_filePath);

            if (_exchangeType.Equals("export"))
            {
                if (uiApp.ActiveUIDocument == null) return;

                var doc = uiDoc.Document;
                var ifcExportOptions = new IFCExportOptions();
                using (var transaction = new Transaction(doc))
                {
                    transaction.Start("Export to ifc");
                    var ifcFile = new FileInfo(_ifcPath);
                    doc.Export(ifcFile.DirectoryName,ifcFile.Name, ifcExportOptions);
                    transaction.RollBack();
                }
            }
            else if (_exchangeType.Equals("import"))
            {
                TaskDialog.Show("Exchange", "Import");
            }

            mutex.ReleaseMutex();
        }

        public Result OnShutdown(UIControlledApplication a)
        {
            return Result.Succeeded;
        }
    }
}
