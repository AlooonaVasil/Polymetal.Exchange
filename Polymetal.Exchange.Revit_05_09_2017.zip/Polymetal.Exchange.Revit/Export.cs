﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using Polymetal.Exchange.Utilities;

namespace Polymetal.Exchange.Revit
{
    public class Export
    {
        private const string IfcPath = @"C:\Aveva\temp\Revit\";
        private const string _revitPath = @"C:\Program Files\Autodesk\Revit 2015\Revit.exe";
        private static XmlSerializer _xmlFormat = new XmlSerializer(typeof(RevitElement), new[] { typeof(Extrusion), typeof(Circle) });

        public static bool Run(int triggerId)
        {
            var swa = new Stopwatch();
            swa.Start();
            decimal projectId, status;
            Common.Source source;
            if (!Common.GetTriggerInfoById(triggerId, out projectId, out source, out status)) return false;
            var modelName = new ProjectInformation(projectId).Program.Path;

            var file = new FileInfo(modelName);
            if (!file.Exists) return false;
            var tempFile = file.CopyTo(Path.Combine(file.DirectoryName, "tmp.rvt"),true);
            if (!tempFile.Exists) return false;

            var ifcFile = new FileInfo(Path.Combine(IfcPath, projectId + ".ifc"));
            if (ifcFile.Exists)
                ifcFile.Delete();
            Console.WriteLine("{0}: Запуск Revit", DateTime.Now.ToLongTimeString());

            var mutex = new Mutex(false, "ExchangeMutex");
            var mutexFiles = Directory.GetFiles(tempFile.DirectoryName, "mutex.init");
            foreach (var f in mutexFiles)
            {
                File.Delete(f);
            }

            var oldDir = Environment.CurrentDirectory;
            Environment.SetEnvironmentVariable("PLMT_EXCHANGE", tempFile.FullName + "#" + "export" + "#" + Path.Combine(IfcPath, projectId + ".ifc"));
            var proc = new Process();
            proc.StartInfo = new ProcessStartInfo(_revitPath, "/language RUS");
            proc.StartInfo.WorkingDirectory = oldDir;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.EnableRaisingEvents = true;
            proc.Start();

            mutexFiles = Directory.GetFiles(tempFile.DirectoryName, "mutex.init");
            while (mutexFiles.Length == 0)
            {
                Thread.Sleep(1000);
                mutexFiles = Directory.GetFiles(tempFile.DirectoryName, "mutex.init");
            }

            foreach (var f in mutexFiles)
            {
                File.Delete(f);
            }
            
            mutex.WaitOne();
            proc.CloseMainWindow();
            mutex.ReleaseMutex();
            while (File.Exists(tempFile.FullName))
            {
                try
                {
                    tempFile.Delete();
                }
                catch{}
                Thread.Sleep(1000);
            }

            
            swa.Stop();

            Console.WriteLine("Экспорт выполнен за {0}:{1}", swa.Elapsed.Minutes, swa.Elapsed.Seconds);

            ifcFile = new FileInfo(Path.Combine(IfcPath, projectId + ".ifc"));
            if (!ifcFile.Exists) return false;

            var revitItems = IfcParser.RunParse(ifcFile.FullName);
            ifcFile.Delete();

            if (revitItems.Count == 0) return true;
           
            var dt = Common.CreateRevitTable();
            var allGuidDt = Common.CreateRevitTable();
            foreach (var item in revitItems)
            {
                var row = dt.NewRow();
                var itemGuid = CalculateMD5Hash(item.Id);
                row["element_guid"] = itemGuid;
                row["element_type"] = item.Properties.Type;

                using (var stream = new StringWriter())
                {
                    _xmlFormat.Serialize(stream, item);
                    row["element_info"] = stream.ToString();
                }
                dt.Rows.Add(row);

                var gr = allGuidDt.NewRow();
                gr["element_guid"] = itemGuid;
                allGuidDt.Rows.Add(gr);
            }

            Console.WriteLine("Обновляем данные в SQL");
            var result = Common.UpdateSql(dt, allGuidDt, Common.Source.Revit, projectId, triggerId);
            Console.WriteLine(result ? "Данные обновлены" : "Данные не обновлены");

            var tmpFiles = Directory.GetFiles(IfcPath);
            foreach (var f in tmpFiles)
            {
                try
                {
                    File.Delete(f);
                }
                catch { } 
            }

            return result;
        }

        public static string CalculateMD5Hash(string input)
        {
            var md5 = MD5.Create();
            var inputBytes = Encoding.ASCII.GetBytes(input);

            var hash = md5.ComputeHash(inputBytes);

            var sb = new StringBuilder();
            foreach (var b in hash)
            {
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();

        }

        //private static void ClearTempDirectory(string tempModelName)
        //{
        //    try
        //    {
        //        var modelFile = new FileInfo(tempModelName);
        //        var dir = modelFile.Directory;
        //        var files = dir.GetFiles();
        //        foreach (var f in files)
        //            f.Delete();
        //        dir.Delete();

        //        var ifcFiles = Directory.GetFiles(IfcPath, "*.ifc*");
        //        foreach (var f in ifcFiles)
        //        {
        //            File.Delete(f);
        //        }
        //    }
        //    catch (Exception exc)
        //    {
        //        Console.WriteLine(exc.Message);
        //    }
        //}

        //private static string CreateSrcFile()
        //{
        //    var filePath = Path.Combine(Environment.CurrentDirectory, "ExportMagicCAD.scr");
        //    try
        //    {
        //        using (var sw = new StreamWriter(filePath, false, Encoding.UTF8))
        //        {
        //            sw.WriteLine("-MAGIIFC export");
        //            sw.WriteLine();
        //            sw.WriteLine("_.undo ОБРАТНО Д");
        //            sw.WriteLine("_.quit Д");
        //            sw.WriteLine();
        //            sw.Close();
        //        }
        //    }
        //    catch (IOException ioex)
        //    {
        //        Console.WriteLine(ioex.Message);
        //        return string.Empty;
        //    }

        //    return File.Exists(filePath) ? filePath : string.Empty;
        //}
    }
}
